export default function TeamPage() {
  return (
    <>
      <h1>TeamPage</h1>
    </>
  );
}
