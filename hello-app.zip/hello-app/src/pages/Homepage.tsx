import Card from "../components/Card";

export default function Homepage() {
  return (
    <>
      <h1>Homepage</h1>
      <p>Paragraph</p>
      <Card />
    </>
  );
}
