export default function ProfilePage() {
  return (
    <>
      <h1>ProfilePage</h1>
      <p>Profile Paragraph</p>
    </>
  );
}
