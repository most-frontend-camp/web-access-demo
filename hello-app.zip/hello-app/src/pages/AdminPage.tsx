export default function AdminPage() {
  return (
    <>
      <h1>AdminPage</h1>
    </>
  );
}
