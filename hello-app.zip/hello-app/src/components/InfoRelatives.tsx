export default function NoPage() {
  return (
    <>
      <h1>Page not found</h1>
    </>
  );
}
