export default function InfoAdditional() {
  return (
    <>
      <h1>InfoAdditional</h1>
    </>
  );
}
